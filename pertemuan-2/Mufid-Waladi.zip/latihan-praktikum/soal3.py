tim_frontend = {"HTML", "CSS", "JavaScript", "React"}
tim_backend = {"Python", "JavaScript", "SQL",
"NodeJS"}

irisan = tim_frontend.intersection(tim_backend)

ahli_backend = (" ")
for x in tim_backend:
    ahli_backend += x + " " 
#no.2

semua = tim_frontend.union(tim_backend)
#no.3