barang = ("B001", "Laptop Gaming", 15000000)
print(barang[2])
#barang[2] = 14000000 error karna tuple tidak bisa di ubah

(kode, nama, harga) = barang