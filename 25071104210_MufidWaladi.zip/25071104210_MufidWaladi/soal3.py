katalog = [ {'merk': 'Samsung', 'tipe': 'S23', 'sn': 'SAM01', 'stok':2}, 
           {'merk': 'Oppo', 'tipe': 'Reno 10', 'sn': 'OPP01', 'stok': 5} ]

def update_stok(katalog, sn_target, jumlah_tambah):
    for x in katalog:
        if x['sn'] == sn_target:
            x['stok'] = jumlah_tambah

sn_target = str(input("Masukkan kode sn "))
jumlah_tambah = int(input("Masukkan jumlah penambahan "))

update_stok(katalog, sn_target, jumlah_tambah)
print(katalog)

for x in katalog:
    