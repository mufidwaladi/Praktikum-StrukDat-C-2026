stok_gadget = [
{'merk': 'Samsung', 'tipe': 'S23', 'harga': 12000000},
{'merk': 'Oppo', 'tipe': 'Reno 10', 'harga': 6000000},
{'merk': 'Xiaomi', 'tipe': 'Mi 13', 'harga': 10000000},
{'merk': 'Iphone', 'tipe': '15 Pro', 'harga': 20000000},
]

def filter_harga(data, min_harga, max_harga):
    
    for x in stok_gadget:
        if x['harga'] >= min_harga and x['harga'] <= max_harga:
            print(x['merk'])
        else:
            print("Tidak ada gadget dalam rentang harga tersebut.")

min_harga = int(input("Masukkan batas bawah"))
max_harga = int(input("Masukkan batas atas"))
filter_harga(stok_gadget,min_harga,max_harga)