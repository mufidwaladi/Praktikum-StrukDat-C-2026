gadget = [{

}]

def registrasi_gadget(merk, tipe, harga, sn):
    if harga < 1000000:
        print("Harga salah")
    if len(sn) == 5:
        print("serial number salah")

        return {
            ["merek"] : [merk],
            ["tipe"] : [tipe],
            ["harga"] : [harga],
            ["sn"] : [sn],
            ["status"] : ["Tersedia"],
        }
    else:
        return None
    
p = len(gadget)
for i in range(p):
    m = str(input("masukkan merek barang "))
    t = str(input("masukkan tipe barang "))
    h = float(input("Masukkan harga barang "))
    s = str(input("Masukkan serial number "))
    gadget = registrasi_gadget(m, t, h, s)
gadget.append(registrasi_gadget)